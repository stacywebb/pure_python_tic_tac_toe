__version__ = '1.0.0'
__author__ = 'Stacy E. Webb'
__project__= 'Tic_Tac_Toe Test for Coxmedia'
