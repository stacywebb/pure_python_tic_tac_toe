from distutils.core import setup

setup(
	name='tic_tac_toe',
	version='1.0.0',
	packages=[''],
	url='http://stacywebb.com',
	license='GPL',
	author='Stacy E Webb',
	author_email='stacywebb@gmail.com',
	description='Tic_Tac_Toe_Pure_Python'
)
